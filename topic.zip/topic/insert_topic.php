<?php

$conn = mysqli_connect('localhost','root','');

if(!$conn) {
	echo 'not connected';
}
if (!mysqli_select_db($conn,'topic')) {
	echo 'no database';
}

$topic=$_REQUEST["topic"];
$chapter_name = $_POST['chapter_name'];
$chapter_description = $_POST['chapter_description'];

$sql = "INSERT INTO ".$topic." (chapter_name, chapter_description) values ('$chapter_name', '$chapter_description')";

if(!mysqli_query($conn,$sql)) {
	echo 'not inserted';
} else {
	echo 'inserted';
}
header("refresher:2 url=page.html");

?>