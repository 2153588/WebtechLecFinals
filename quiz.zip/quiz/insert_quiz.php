<?php

$conn = mysqli_connect('localhost','root','');

if(!$conn) {
	echo 'not connected';
}
if (!mysqli_select_db($conn,'topic')) {
	echo 'no database';
}

$topic=$_REQUEST["topic"];
$question_id = $_POST['question_id'];
$question_description = $_POST['question_description'];
$question_number = $_POST['question_number'];
$question_answer = $_POST['question_answer'];

$sql = "INSERT INTO ".$topic." (question_id, question_desc, question_number, question_answer) values ('$question_id', '$question_description', '$question_number', '$question_answer')";

if(!mysqli_query($conn,$sql)) {
	echo 'not inserted';
} else {
	echo 'inserted';
}
header("refresher:2 url=quiz.html");

?>