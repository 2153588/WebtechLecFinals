</div>
	</main>
	<footer>
		<div class="container">
			Copyright &copy; 2018, Ruby On Rails Quizzer
		</div>
	</footer>
</body>
</html>