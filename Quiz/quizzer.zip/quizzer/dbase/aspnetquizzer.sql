-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2018 at 08:28 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aspnetquizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'Active Server Pages'),
(2, 1, 0, 'Active Sign Pages'),
(3, 1, 0, 'Active Service Page'),
(4, 1, 0, 'Active Some Page'),
(5, 2, 1, 'True'),
(6, 2, 0, 'False'),
(7, 3, 1, 'Microsoft'),
(8, 3, 0, 'Apple'),
(9, 3, 0, 'Linux'),
(10, 3, 0, 'Toshiba'),
(11, 4, 0, 'Application Program Interface'),
(12, 4, 1, 'Internet of Things'),
(13, 4, 0, 'Laravel'),
(14, 4, 0, 'Bootsrap'),
(15, 5, 0, '2004'),
(16, 5, 0, '2001'),
(17, 5, 1, '2002'),
(18, 5, 0, '2003'),
(19, 6, 1, 'WYSIWYG'),
(20, 6, 0, 'XHTML'),
(21, 6, 0, 'DOCTYPE html'),
(22, 6, 0, 'Dreamweaver'),
(23, 7, 0, 'client'),
(24, 7, 1, 'server'),
(25, 8, 1, 'True'),
(26, 8, 0, 'False'),
(27, 9, 1, 'True'),
(28, 9, 0, 'False'),
(29, 10, 0, 'True'),
(30, 10, 1, 'False');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What does ASP stand for?'),
(2, 'Does ASP.Net build on a Common Language Runtime?'),
(3, 'ASP.Net was developed by?'),
(4, 'The framework supports the creation web applications and services that includes?'),
(5, 'ASP.Net was developed in what year?'),
(6, 'This has been designed to work smoothly, with the _______ HTML editors.'),
(7, 'ASP.Net is a ______-side web framework'),
(8, 'This Open-source server-side framework for web applications is usually used to produce dynamic web pages.'),
(9, 'Asp.net core is a cross- platform framework with high implementations for the development of cloud-based web applications.'),
(10, 'Common Language Runtime or CLR for short, which does not allow the programmers write ASP.Net code using any of the .Net languages.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
