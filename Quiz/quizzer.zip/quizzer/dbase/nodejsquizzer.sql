-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2018 at 08:28 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nodejsquizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 0, 'Bill Gates'),
(2, 1, 0, 'Steve Jobs'),
(3, 1, 1, 'Ryan Dahl'),
(4, 1, 0, 'Tim Berners-Lee'),
(5, 2, 1, 'True'),
(6, 2, 0, 'False'),
(7, 3, 0, 'True'),
(8, 3, 1, 'False'),
(9, 4, 0, 'True'),
(10, 4, 1, 'False'),
(11, 5, 1, 'True'),
(12, 5, 0, 'False'),
(13, 6, 1, 'True'),
(14, 6, 0, 'False'),
(15, 7, 1, '2009'),
(16, 7, 0, '2003'),
(17, 7, 0, '2001'),
(18, 7, 0, '2005'),
(19, 8, 1, 'True'),
(20, 8, 0, 'False'),
(21, 9, 1, 'True'),
(22, 9, 0, 'False'),
(23, 10, 1, '1995'),
(24, 10, 0, '1996'),
(25, 10, 0, '1997'),
(26, 10, 0, '1998');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'Who introduce the JavaScript based Node.js platform?'),
(2, 'Node.js is an open source server environment which is free.'),
(3, 'Node.js uses a Synchronous programming method.'),
(4, 'Node.js is multi-threaded, non-blocking, asynchronous program which is very memory efficient.'),
(5, 'Node.js can generate dynamic page content and also open, read, write, delete, and close files in the server.'),
(6, 'Node.js runtime system builds a network with other event-based application servers.'),
(7, 'In what year does the JavaScript-based Node.js platform was introduced by Ryan Dahl?'),
(8, 'The high level Node.js combines the Google V8 JavaScript engine.'),
(9, 'A Node.js file contains the tasks that will be executed in certain events for example; someone is accessing a port on the server.'),
(10, 'In this year, a contractor to Netscape named Brendan Eich created the JavaScript Language in order to run web browsers.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
