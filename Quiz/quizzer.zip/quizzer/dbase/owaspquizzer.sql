-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2018 at 08:28 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `owaspquizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 0, 'Broken Authentication'),
(2, 1, 1, 'Injection'),
(3, 1, 0, 'Broken Access Control'),
(4, 1, 0, 'Insecure Deserialization'),
(5, 2, 1, 'True'),
(6, 2, 0, 'False'),
(7, 3, 0, 'December 25, 2001'),
(8, 3, 1, 'December 1, 2001'),
(9, 3, 0, 'December 21, 2003'),
(10, 3, 0, 'December 24, 2003'),
(11, 4, 0, 'Using Components with Known Vulnerabilities'),
(12, 4, 1, 'Insecure Deserialization'),
(13, 4, 0, 'Insufficient Logging and monitoring'),
(14, 4, 0, 'Broken Access Control'),
(15, 5, 0, 'True'),
(16, 5, 1, 'False'),
(17, 6, 1, 'XML External Entities'),
(18, 6, 0, 'Broken Authentication'),
(19, 6, 0, 'Injection'),
(20, 6, 0, 'Broken Access Control'),
(21, 7, 0, 'True'),
(22, 7, 1, 'False'),
(23, 8, 0, 'True'),
(24, 8, 1, 'False'),
(25, 9, 0, 'Injection'),
(26, 9, 0, 'Insufficient Logging and Monitoring'),
(27, 9, 0, 'Security Misconfiguration'),
(28, 9, 1, 'Sensitive Data Exposure'),
(29, 10, 1, 'True'),
(30, 10, 0, 'False');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, '______ occurs when an application sends user input to  an interpreter without sanitising it first.'),
(2, 'OWASP is an organization that is open to the community.'),
(3, 'OWASP was founded online on what year?'),
(4, 'The application is all about remote code execution which is the most dangerous attacks made by hackers.'),
(5, 'OWASP stands for Open Web Application Services Project.'),
(6, 'The application allows hackers to utilize the vulnerability of XML processors.'),
(7, 'Cross-site scripting is a common issue because of the default configuration that hackers could attack easily.'),
(8, 'OWASP is a private organization that keeps all files hidden from the community.'),
(9, 'Hackers target protected data in many credit cards, identity theft and many more other crimes.'),
(10, 'Hackers attack through the system with tampering extraction is under Insufficient Logging and Monitoring application.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
