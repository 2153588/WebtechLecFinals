-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2018 at 08:29 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rubyonrailsquizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'True'),
(2, 1, 0, 'False'),
(3, 2, 0, 'PHP'),
(4, 2, 0, 'Java'),
(5, 2, 0, 'JavaScript'),
(6, 2, 1, 'Ruby'),
(7, 2, 0, 'None of the Above'),
(8, 3, 0, '2000'),
(9, 3, 0, '2007'),
(10, 3, 1, '2003'),
(11, 3, 0, '2005'),
(12, 4, 0, 'Brendan Eich'),
(13, 4, 0, 'Yukihiro Matsumoto'),
(14, 4, 1, 'David Heinemeir Hansson'),
(15, 4, 0, 'Heinz Doofenshmirtz'),
(16, 5, 1, '2005'),
(17, 5, 0, '2003'),
(18, 5, 0, '2000'),
(19, 5, 0, '2004'),
(20, 6, 0, 'MVC'),
(21, 6, 1, 'DRY'),
(22, 6, 0, 'Convention Over Configuration'),
(23, 6, 0, 'DSS'),
(24, 7, 1, 'Active Record Pattern'),
(25, 7, 0, 'MVC'),
(26, 7, 0, 'DRY'),
(27, 7, 0, 'Convention Over Configuration'),
(28, 8, 1, 'True'),
(29, 8, 0, 'False'),
(30, 9, 0, 'Apple'),
(31, 9, 1, 'Basecamp'),
(32, 9, 0, 'Ruby'),
(33, 9, 0, 'Github'),
(34, 10, 0, '2000'),
(35, 10, 0, '2003'),
(36, 10, 1, '2007'),
(37, 10, 0, '2001');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'Ruby on Rails is a web application development framework.'),
(2, 'Ruby on rails was written in what programming language?'),
(3, 'What year does rails created?'),
(4, 'Who created rails?'),
(5, 'What year does rails version 1.0 officially released?'),
(6, '______ is a software principle that aims to reduce repetition in the code.'),
(7, '______ is an approach in accessing data in your database.'),
(8, 'Ruby on rails allows you to code less at the same time accomplish more.'),
(9, 'Rails was a buy product of ______.'),
(10, 'A milestone achieved by Rails was when Apple agreed to release the Mac OS X v10.5 â€œLeopardâ€ together with Rails which happened in what year?');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
