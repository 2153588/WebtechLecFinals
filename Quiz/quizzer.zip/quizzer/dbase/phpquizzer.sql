-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2018 at 08:29 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpquizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'PHP: Hypertext Preprocessor'),
(2, 1, 0, 'Personal Hit Ping'),
(3, 1, 0, 'Personal Hypertext Processor'),
(4, 1, 0, 'PHP: Home Page'),
(5, 2, 0, 'Ruby'),
(6, 2, 1, 'C'),
(7, 2, 0, 'Swift'),
(8, 2, 0, 'Node.js'),
(9, 3, 0, 'Ramos Kyrie'),
(10, 3, 1, 'Ramsus Lerdorf'),
(11, 3, 0, 'Ramsus Ledof'),
(12, 3, 0, 'Ramos JC'),
(13, 4, 0, 'Personal Heart Page'),
(14, 4, 0, 'Put Hypertext Preprocessor'),
(15, 4, 0, 'Personal Hypertext Processor'),
(16, 4, 1, 'Personal Home Page'),
(17, 5, 0, '@'),
(18, 5, 0, '!'),
(19, 5, 1, '$'),
(20, 5, 0, '^'),
(21, 6, 1, 'PHP-enabled computers'),
(22, 6, 0, 'C-enabled computers'),
(23, 7, 1, 'True'),
(24, 7, 0, 'False'),
(25, 8, 1, 'True'),
(26, 8, 0, 'False'),
(27, 9, 0, 'True'),
(28, 9, 1, 'False'),
(29, 10, 1, 'True'),
(30, 10, 0, 'False'),
(31, 11, 1, 'afsdf'),
(32, 11, 0, 'sdfsdf'),
(33, 11, 0, 'sdfsdf'),
(34, 11, 0, 'sfsfd'),
(35, 12, 0, 'sdfsdfdf'),
(36, 12, 0, 'dsfsdfsdf'),
(37, 12, 0, 'sdfsdf'),
(38, 12, 1, 'sdfsdf'),
(39, 12, 0, 'sdfsdfsdfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What does PHP stand for?'),
(2, 'PHP was written by what programming language?'),
(3, 'Who is the creator of this web scripting language?'),
(4, 'PHP before stands for?'),
(5, 'For declaring variables in PHP, you should start with what sign?'),
(6, 'PHP code can only be executed on?'),
(7, 'The PHP data types allow variables to store data in different types.'),
(8, 'The Boolean symbolizes the x and y for True and False and booleans are usually used for conditional testing.'),
(9, 'PHP resource is a data type but it stores quotations to the functions and external resources in PHP.'),
(10, 'PHP 5-updated Zend Engine 2.0 released in July 2004.'),
(11, 'sdasdasdasda'),
(12, 'sdasdasd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
