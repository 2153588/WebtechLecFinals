-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2018 at 08:27 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jspquizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'Java Server Page'),
(2, 1, 0, 'Java Space Provider'),
(3, 1, 0, 'Java Sign Page'),
(4, 1, 0, 'Java Server Provider'),
(5, 2, 0, 'True'),
(6, 2, 1, 'False'),
(7, 3, 1, 'True'),
(8, 3, 0, 'False'),
(9, 4, 1, 'True'),
(10, 4, 0, 'False'),
(11, 5, 0, 'True'),
(12, 5, 1, 'False'),
(13, 6, 1, 'True'),
(14, 6, 0, 'False'),
(15, 7, 1, 'True'),
(16, 7, 0, 'False'),
(17, 8, 0, 'True'),
(18, 8, 1, 'False'),
(19, 9, 1, 'True'),
(20, 9, 0, 'False'),
(21, 10, 0, 'True'),
(22, 10, 1, 'False');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What does JSP stand for?'),
(2, 'A java servlet does not allow the web server to be accessed by web developers in a simpler or efficient way in business systems.'),
(3, 'A servlet is a java programming language class that extends the attributes for the servers.'),
(4, 'Does it serves as a Java platform technology provided in a component-based, platform-independent method in the structure of web-based application?'),
(5, 'The technology provides hard and slow development for web developers and web designers'),
(6, 'Java Server Pages is an extension of Java Servlet technology.'),
(7, 'Java Server Pages(JSP) technology uses XML tags which summarizes the logical content of the webpage.'),
(8, 'The technology does not separate the User Interface(UI) from the content and enables web designers to change the layout of the web page without changing the primary dynamic content.'),
(9, 'The function of a server enables back-end software'),
(10, 'Server side web scripting technologies are used for back-end web development technologies');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
