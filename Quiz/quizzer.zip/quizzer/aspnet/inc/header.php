<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8" />
	<title>Quiz</title>
	<link rel="stylesheet" href="css/quiz.css" type="text/css" />
</head>
<body>
	<header>
		<div class="container">
			<h1>Quiz</h1>
		</div>
	</header>
	<main>
		<div class="container">