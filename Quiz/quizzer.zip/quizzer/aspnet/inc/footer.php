</div>
	</main>
	<footer>
		<div class="container">
			Copyright &copy; 2018, ASP.Net Quizzer
		</div>
	</footer>
</body>
</html>